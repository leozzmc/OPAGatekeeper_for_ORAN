### Expect Result

```
{
    "deny": [
        "Image 'mysql' comes from untrusted registry"
    ]
}
```